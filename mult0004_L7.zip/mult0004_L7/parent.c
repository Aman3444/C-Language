/* PROGRAM: lab 7
   AUTHOR: Aman Multani
   DATE:   01/09/2018
   PURPOSE: Set up bi directional communication between two process and using file descriptiors. 
   LEVEL OF DIFFICULTY: 5/5
   CHALLENGES: Facing difficulty with sending message and forking.
   HOURS SPENT: 5 hour
*/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

/**	fdRead -- descriptor for reading data from child 
	fdWrite -- descriptor for writing data to child **/
void runAsParent(int fdRead, int fdWrite){
	srand(time(0)); /* Initialize random number generator with a seed */

	/* Write and Read buffers */
	char writeBuff[2];
	char readBuff[1024];

	int response; /* To store response from child */

	while(1){
		sprintf(writeBuff, "%d", rand()%3+1); /* Write random number (1, 2 or 3) to the write buffer */
		write(fdWrite, writeBuff, strlen(writeBuff)+1); /* Write the data using fdWrite */

		if(read(fdRead, readBuff, sizeof(readBuff)) < 0){ /* Blocking read to get response from the child */
			fprintf(stderr, "Failed to read response from child\n");
			return;
		}

		sscanf(readBuff, "%d", &response); /* Convert the response to an integer */
		if(response <= 0){ /* Check if reponse if non-positive (condition for ending the simulation */
			return;
		}

		sleep(rand()%5+1); /* Sleep for a random number of seconds from 1 to 5 */
	}
}
