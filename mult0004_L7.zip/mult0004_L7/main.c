/* PROGRAM: lab 7
   AUTHOR: Aman Multani
   DATE:   01/09/2018
   PURPOSE: Set up bi directional communication between two process and using file descriptiors. 
   LEVEL OF DIFFICULTY: 5/5
   CHALLENGES: Facing difficulty with sending message and forking.
   HOURS SPENT: 5 hour
*/

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>

void runAsParent(int,int); /* Function called in parent process (defined in parent.c) */
void runAsChild(int,int); /* Function called in child process (defined in child.c) */

int main(){
	int p2c[2]; /* Pipe for parent to child transfer */
	int c2p[2]; /* Pipe for child to parent transfer */

	if(pipe(p2c)==-1){ /* Error check for parent to child pipe */
		fprintf(stderr, "Failed to create pipe: p2c\n");
		return 1;
	}

	if(pipe(c2p)==-1){ /* Error check for parent to child pipe */
		fprintf(stderr, "Failed to create pipe: c2p\n");

		/* Close the parent to child pipe also before quiting */
		close(p2c[0]); 
		close(p2c[1]);
		return 1;
	}

	pid_t pid = fork(); /* Fork the child process */

	if(pid < 0){ /* Check for error while forking the child process */
		fprintf(stderr, "Failed to fork a process\n");

		/* Close both the pipes before quiting */
		close(p2c[0]);
		close(p2c[1]);
		close(c2p[0]);
		close(c2p[1]);
		return 1;
	}

	if(pid > 0){ /* Fork returns child process's pid (>0) in the parent process */
		/* Close reading end of parent to child pipe and writing end of child to parent pipe */
		close(p2c[0]);
		close(c2p[1]);

		runAsParent(c2p[0], p2c[1]); /* Call the function supposed to simulate parent's behaviour */

		/* Close the open ends of both pipes since the parent simulation has finished */
		close(p2c[1]);
		close(c2p[0]);
	}else{
		/* Close reading end of child to parent pipe and writing end of parent to child pipe */
		close(p2c[1]);
		close(c2p[0]);
		
		runAsChild(p2c[0], c2p[1]); /* Call the function supposed to simulate child's behavious */

		/* Close the open ends of both pipes since the child simulation has finished */
		close(p2c[0]);
		close(c2p[1]);
	}

	return 0;
}
