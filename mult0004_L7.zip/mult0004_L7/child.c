/* PROGRAM: lab 7
   AUTHOR: Aman Multani
   DATE:   01/09/2018
   PURPOSE: Set up bi directional communication between two process and using file descriptiors. 
   LEVEL OF DIFFICULTY: 5/5
   CHALLENGES: Facing difficulty with sending message and forking.
   HOURS SPENT: 5 hour
*/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

/**	total -- pointer to the total counter **/
void idle(int *total){
	*total -= 1; /* Decrement the total by 1 */
	printf("now total = %d\n", *total); /* Print the  total */
	sleep(1); /* Sleep for 1 second */
}

/**	fdRead -- descriptor for reading data from parent 
	fdWrite -- descriptor for writing data to parent **/
void runAsChild(int fdRead, int fdWrite){
	/* Read and Write buffers */
	char readBuff[2];
	char writeBuff[1024];

	int total = 10; /* Total counter */
	int nRead, n;

	/* Set the fdRead (descriptor for reading data from parent) as non-blocking */
	int flags = fcntl(fdRead, F_GETFL, 0);
	if(fcntl(fdRead, F_SETFL, flags | O_NONBLOCK) < 0){ /* Error check if it was successful */
		fprintf(stderr, "Failed to set non blocking read in child.\n");
		return;
	}

	while(1){
		nRead = read(fdRead, readBuff, 2); /* Read from child using fdRead */
		
		if(nRead > 0){ /* Read was successful and there was data */
			sscanf(readBuff, "%d", &n); /* Convert the data into integer */

			total += n; /* Increment the total counter */
			printf("Got %d, so now total is %d\n", n, total); /* Print the total */

			sprintf(writeBuff, "%d", total); /* Write the total to write buffer */
			write(fdWrite, writeBuff, strlen(writeBuff)+1); /* Send the total to parent using fdWrite */
		}else if(nRead < 0){ /* Read was not successful */
			if(errno == EAGAIN){ /* The pipe was empty and we need to try again */
				idle(&total); /* Call the idle task */
			}else{ /* Error in read */
				fprintf(stderr, "Failed to read from parent\n");
				exit(1);
			}
		}else{ /* End of input from the parent */
			return;
		}
	}
}
