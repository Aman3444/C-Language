/* PROGRAM:  CST8234_010 
   AUTHOR:   Aman Multani 
   DATE:     28/11/17 
   TOPIC:    LinkedList 
   PURPOSE:  Adding and Sorting in linkedlist
   CHALLENGES: Randomly Deleting
   LEVEL OF DEFFICULTY : 5
   TIME SPEND : 4 DAYS
*/

#ifndef SLINK
#define SLINK
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
struct LinkedList {
    int data;
    struct LinkedList* next;
};
typedef struct LinkedList* node; /* define node as pointer of data type struct Linklist */

node createNode()
{
    node temp; /* declare node */
    temp = (node)malloc(sizeof(struct LinkedList)); /* allocate memory using malloc */
    temp->next = NULL; /* make next point null */
    return temp; /* return new node */
}

node addNode(node ptr, int value)
{
    int count;
    int c;
    int data1;
    int num;
    node trav = 0;
    node trav1 = 0;
    node trav2 = 0;
    node temp, p;
    temp = createNode(); /* create node will return a new node with data = value and next pointing to null */
    temp->data = value;

    count = 1;

    trav = createNode();
    trav1 = createNode();
    trav2 = createNode();

    if (ptr == NULL) {
        ptr = temp; /* when linked list is empty */
    }
    else {
        p = ptr; /* assign head to p */
        while (p->next != NULL) {
            p = p->next; /* traverse the list until p is the last node .*/
            count++;
        }
        p->next = temp; /* point the previous lasst node to the new code created */

        trav = ptr;
        trav1 = ptr;

        for (c = 0; c < count; c++) {
            trav = trav1;
            trav2 = trav1;
            trav1 = trav1->next;
            num = trav->data;
            while (trav->next != NULL) {
                data1 = trav->next->data;
                if (num > data1) {
                    trav2->data = data1;
                    trav->next->data = num;
                }
                trav = trav->next;
            }
        }
    }
    return ptr;
}

node deleteNodes(node secondptr, int* countNodes, int rnd)
{
    node temp1 = createNode();
    node temp2 = createNode();
    node root = secondptr;

    int h;
    int j;
    if (rnd == 0) {
        temp1 = secondptr;
        root = secondptr->next;
        secondptr = secondptr->next;
        printf("Deleting : %d  \n", temp1->data);
        free(temp1);
        *countNodes = *countNodes - 1;
        printf("List : [");
        for (h = 0; h < *countNodes; h++) {
            printf("%d ", secondptr->data);
            secondptr = secondptr->next;
        }
        printf("] \n");
        return root;
    }
    else if (rnd == *countNodes) {
        root = secondptr;
        while (secondptr->next->next != NULL) {
            secondptr = secondptr->next;
        }
        temp1 = secondptr->next;
        secondptr->next = 0;
        /*deleting from end */
        printf("Deleting : %d \n", temp1->data);
        free(temp1);
        *countNodes = *countNodes - 1;

        printf("List : [");
        for (h = 0; h < *countNodes; h++) {
            printf("%d ", secondptr->data);
            secondptr = secondptr->next;
        }
        printf("] \n");
        return root;
    }

    for (j = 0; j < rnd; j++) {
        if (j == rnd - 1) {
            /*deleting between*/
            root = secondptr;
            temp2 = secondptr->next->next;
            temp1 = secondptr->next;
            printf("Deleting : %d  \n", temp1->data);
            free(temp1);
            *countNodes = *countNodes - 1;
            secondptr->next = temp2;
            printf("List : [");
            for (h = 0; h < *countNodes; h++) {
                printf("%d, ", secondptr->data);
                secondptr = secondptr->next;
            }
            printf("] \n");
            return root;
        }
    }

    return 0;
}

#endif
