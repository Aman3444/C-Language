/* PROGRAM:  CST8234_010 
   AUTHOR:   Aman Multani 
   DATE:     28/11/17 
   TOPIC:    LinkedList 
   PURPOSE:  Adding and Sorting in linkedlist
   CHALLENGES: Randomly Deleting
   LEVEL OF DEFFICULTY : 5
   TIME SPEND : 4 DAYS
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "slink.h"
int main(void)
{
    int num;
    int z;
    int randNum;
    int countNodes;
    node root;
    node test = 0;
    time_t timeRandom;

    node secondPtr = 0;

    printf("\n");
    printf(" Numbers to add to list ?:");

    num = 0;
    scanf("%d", &num);

    z = 0;
    root = 0;
    srand((unsigned)time(&timeRandom));

    randNum = rand() % 1000;
    root = addNode(root, randNum);
    test = createNode();

    printf("inserting  : %d  \n", randNum);
    printf("List : [");
    test = root;

    printf("%d", root->data);

    printf("] \n");

    for (z = 0; z < num - 1; z++) {
        randNum = rand() % 1000;
        printf("inserting : %d  \n", randNum);
        root = addNode(root, randNum);
        printf("List : [");
        test = root;
        while (test->next != NULL) {
            printf("%d, ", test->data);
            test = test->next;
        }
        printf("%d ", test->data);
        printf("] \n");
    }
    countNodes = num;
    secondPtr = createNode();

    for (z = 0; z < num; z++) {
        randNum = rand() % countNodes;
        secondPtr = root;
        root = deleteNodes(secondPtr, &countNodes, randNum);
    }
    return 0;
}
