#ifndef PARSE_H
#define PARSE_H

extern int parseArguments( int argc, char *argv[], int *pnCardsPerHand, int *pnHands, int *pisEuchre, int *pmodeSort, int *pmodePrint, long *pnSeed );

#endif
