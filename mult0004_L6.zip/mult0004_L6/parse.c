/* PROGRAM: lab 6
   AUTHOR: Aman Multani
   DATE:   12/05/2017
   PURPOSE: Parsing Arguments in Command Line
   LEVEL OF DIFFICULTY: 5/5
   CHALLENGES: Parsing Command Line
   HOURS SPENT: 10 hours
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "deck.h"
#include <getopt.h>
#include "parse.h"

#define YES 2
#define NO 3

void printhelp()
{
    printf("Usage: lab6 OPTION[S] \n\n\n");

    printf("start the game with these options:\n\n");

    printf("-h, --help                Displays this help\n\n");
    printf("-e, --euchre              Euhre the deck\n\n");
    printf("-p NUM, --players[=NUM]   The number of players, if not a euhre deck.\n");
    printf("                          if euhre deck, this defaults to 4 players\n\n");
    printf("-c NUM, --cards[=NUM      The number of cards per player, if not a euhre deck\n");
    printf("                          if euhre deck, this defaults to 5 cards\n\n");

    printf("-b, --reverse             print reverse/back order for sorted cards\n\n");

    printf("-r NUM, --seed[=NUM]      The numeric random number seed. Defaults to NULL if not "
           "specified\n\n");
    printf("-s NUM, --sort[=NUM]      The sorting method that will be applied before printing out "
           "player's hands\n");
    printf(
        "                          1 = No Sorting, 2 = Sorting by Rank, 3 = Sorting by suit\n\n\n");
    exit(1);
}

int parseArguments(int argc, char* argv[], int* pnCardsPerHand, int* pnHands, int* pisEuchre,
    int* pmodeSort, int* pmodePrint, long* pnSeed)
{
    int nCardsPerHand = 0, nHands = 0, isEuhre = 0, modeSort = SORT_NOSORT,
        modePrint = PRINT_NORMAL, nSeed = 0;
    char c;
    int ret = 0, index;
    struct option arguments_long[] = { { "cards", required_argument, 0, 'c' },
        { "euchre", no_argument, 0, 'e' }, { "reverse", no_argument, 0, 'b' },
        { "players", required_argument, 0, 'p' }, { "seed", required_argument, 0, 'r' },
        { "sort", required_argument, 0, 's' }, { 0, 0, 0, 0 } };
    int euhre_declared = 0;

    /* if no arguments is given this will be displayed */
    if (argc <= 1)
    {
        printf("lab6: missing options\n");
        printf("Try this command'lab6 -h' for more information\n\n");
        return 0;
    }
    /* for getting the help */
    if ((argc == 2) && ((!strcmp(argv[1], "-h") || (!strcmp(argv[1], "--help")))))
        printhelp();

    while ((c = getopt_long(argc, argv, "c:p:eb::r:s:", arguments_long, NULL)) != -1)
    {
        switch (c)
        {
            /* for displaying cards */
            case 'c':
                if (!isdigit(*optarg))
                {
                    printf("Please provide argument for number of cards in digits.\n");
                    return ret;
                }
                nCardsPerHand = atoi(optarg);
                if ((euhre_declared == YES) && (nCardsPerHand != 5))
                    printhelp();
                else
                    euhre_declared = NO;
                break;
            /* for displaying no. of Players */
            case 'p':
                if (!isdigit(*optarg))
                {
                    printf("Please provide argument for number of players in digits.\n");
                }
                nHands = atoi(optarg);
                if ((euhre_declared == YES) && (nHands != 4))
                    printhelp();
                else
                    euhre_declared = NO;
                break;
            /* euhre */
            case 'e':
                euhre_declared = YES;
                isEuhre = 1;
                if (((nHands != -1) && (nHands != 4))
                    || ((nCardsPerHand != -1) && (nCardsPerHand != 5)))
                    printhelp();
                nHands = 4;
                nCardsPerHand = 5;
                modeSort = SORT_BYSUIT;

                break;
            /* reverse print */
            case 'b':
                modePrint = PRINT_REVERSE;
                break;
            /* diplaying the random number for seed */
            case 'r':
                if (!isdigit(*optarg))
                {
                    printf("Please provide argument for seed in digits.\n\n");
                    printhelp();
                }
                nSeed = atoi(optarg);
                break;
            case '?':
                printf("Unknown Error detected !\n\n");
                printhelp();
                break;

            /*for sorting the card 1 for no sort , 2 for sort by rank  and  3 for sort by suits  */
            case 's':
                if (!isdigit(*optarg))
                {
                    printf("Please provide argument for sort method in digits .\n\n");
                    printhelp();
                }
                if (atoi(optarg) == 1)
                    modeSort = SORT_NOSORT;
                else if (atoi(optarg) == 2)
                    modeSort = SORT_BYRANK;
                else if (atoi(optarg) == 3)
                    modeSort = SORT_BYSUIT;
                else
                {
                    printf("Wrong Argument for sorting !\n\n");
                    printhelp();
                }
                break;
            default:
                printf("Unknown Error detected !\n\n");
                printhelp();
                break;
        }
    }

    for (index = optind; index < argc; index++)
    {
        printf("Argument %s not supported\n\n", argv[index]);
        printhelp();
    }

    *pnCardsPerHand = nCardsPerHand;
    *pnHands = nHands;
    *pisEuchre = isEuhre;
    *pmodeSort = modeSort;
    *pmodePrint = modePrint;
    *pnSeed = nSeed;

    return 1;
}

