/* PROGRAM:  lab4
   AUTHOR:  Multani Aman Altaf 
   DATE:  10 - 10 -2017 
   PURPOSE: calculator using random
   LEVEL OF DIFFICULTY: 4
   CHALLENGES: random and swapping
   HOURS SPENT: 2 days          
*/



#include <stdio.h>
#include <stdlib.h>
#include <time.h>



/* declaration*/
float f1, s1, result;
int p, q, i;
int num[] = {0,1,2,3};
int temp;


/*calulations and initialsation*/
typedef struct{
char *operation;
char symbol;
float (*func)(float a,float b);
}listHotkey;



float addition(float a, float b) {
  result = a + b;
  return result;
}

float subtract(float a, float b) {
  result = a - b;
  return result;
}

float multiply(float a, float b) {
  result = a *b;
  return result;
}

float divide(float a, float b) {
  result = a / b;
  return result;
}

int main() {


/* array */
  listHotkey array[] = {
    {
      "addition",
      '+',
      & addition
    },
    {
      "subtract",
      '-',
      & subtract
    },
    {
      "multiply",
      '*',
      & multiply
    },
    {
      "divide",
      '/',
      & divide
    }
  };


/* first input*/

  printf("Enter first operand: ");
  scanf("%f", & f1);
/*
  if (first==0){
printf("Errors \n");
exit(0);

}*/
while (f1<=0){
printf("Invalid input . Enter first operand again : ");
scanf("%f", & f1);

}



/* second input*/
  printf("Enter second operand: ");
  scanf("%f", & s1);


while (s1<=0){
printf("Invalid input . Enter second operand again : ");
scanf("%f", & s1);


}

/* if (s1==0){
printf("Errors no character are accepted\n");
exit(0);

}*/
  

/*randomization and swapping */
srand(time(NULL));

  for (p = 0; p< 4; p++) {
    q = (rand() % 3);
    temp = num[p];
    num[p] = num[q];
    num[q] = temp;
  }

  for (p = 0; p < 4; p++)
    printf("\n%d - %s", p, array[num[p]].operation);



/*choice of function  */
  printf("\nEnter hotkey: ");
  scanf("%d", & p);

 while (p<0 || p>3){
printf("Invalid input try again : ");
scanf("%d", & p);
}


/* printing the answer*/
  printf("%.2f %c %.2f = %.2f\n", f1, array[num[p]].symbol, s1, (array[num[p]].func)(f1, s1));

  return 0;
}


