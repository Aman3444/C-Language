/*

program : CST8234_010
Author : Aman Altaf Multani
Date : 19/09/2017
Purpose : print 7 digit phone number and split in two.
Level of Dificulty : 3
Challenges : Conditions in the if statement
Hours spent : 5

*/

/**************************************************************************/
/* Declare include files
 **************************************************************************/
#include <stdlib.h>
#include <stdio.h>
/**************************************************************************
 * Main
 **************************************************************************/
int main (void)
{
 int i,F,S,D;
i=1;
while(i=1){

printf("Enter phone number :\n");
scanf("%d",&F);


if (F==0)
{
exit(0);
}

else if (F<999999)
{
printf("Mistake Occur : The no. is too short \n ");
printf("Invalid no. is : %d \n",F);
}
else if (F>10000000)
{
printf("Mistake Occur : The no. is too big \n ");
printf("Invaild no. is : %d \n",F);
}
 if (F<10000000 && F>999999)
{
S=F/10000;
D=F%10000;

printf(" The phone no. is : %d-%d\n",S,D);

}

}
return 0;
}

