/*

program : CST8234_010
Author : Aman Altaf Multani
Date : 12/9/2017
Purpose : print 1 to 100 and Display the Multiples of 3 and 7.
Level of Dificulty : 1
Challenges : None
Hours spent : 30 minutes
*/

int main (void)
{
int i;
for (i=1;i<=100;i++)
{
if (i%3==0 && i%7==0)
{
printf("%d i'm multiple of 3 and 7\n",i);
else if (i%3==0)
{

printf("%d i'm multiple of 3\n",i);
}
else if (i%7==0)
{

printf("%d i'm multiple of 7\n",i);
}
else {
printf("%d \n",i);
}
}
return 0;
}


