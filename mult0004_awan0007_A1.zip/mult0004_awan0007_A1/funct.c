/* PROGRAM:  CST8234_010 
   AUTHOR:   Aman Multani , Maryum Awan 
   DATE:     30/11/17 
   TOPIC:    Assignment 1 
   PURPOSE:  To show the information about the student who are enrolled in the course or are on the waiting list. 
   CHALLENGES: randamization.
   LEVEL OF DEFFICULTY : 5
   TIME SPEND : 1 months
           
*/



#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>

#include "funct.h"

/* Initial initialization of Students Info */
void initialize_students(student studarray[])
{
	int id;
	int i;
	id = 1101;
	i=0;
	strcpy(studarray[i].Name.first,"Aman");
	studarray[i].id = id;
	strcpy(studarray[i].Name.last,"Multani");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Maryum");
	strcpy(studarray[i].Name.last,"Awan");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Donald");
	strcpy(studarray[i].Name.last,"Trump");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Justin");
	strcpy(studarray[i].Name.last,"Trudeau");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Mike");
	strcpy(studarray[i].Name.last,"Tyson");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Paul");
	strcpy(studarray[i].Name.last,"Walker");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Salman");
	strcpy(studarray[i].Name.last,"Khan");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Sharukh");
	strcpy(studarray[i].Name.last,"Khan");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Anil");
	strcpy(studarray[i].Name.last,"Ambani");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Tom");
	strcpy(studarray[i].Name.last,"Cruise");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Mary");
	strcpy(studarray[i].Name.last,"Jane");
	id++;
	i++;
	studarray[i].id = id;
	strcpy(studarray[i].Name.first,"Lisa");
	strcpy(studarray[i].Name.last,"Martin");
	id++;
	i++;
	return;
}


/* Initialization of Courses Information */
void initialize_courses(course coursearray[])
{
	int i;
	i=0;
	printf("\n");
	strcpy(coursearray[i].description,"Learning the Fundamental of Programming");
	coursearray[i].max_students = rand()%5 + 4;
	strcpy(coursearray[i].Name," Pearl Programing");
	strcpy(coursearray[i].code,"CS123");
	coursearray[i].reg_list = NULL;
	coursearray[i].waitlist = NULL;
	i++;	
	coursearray[i].max_students = rand()%5 + 4;
	strcpy(coursearray[i].description,"lerning the Fundamental for Web Development");
	strcpy(coursearray[i].Name,"Web Programming");
	strcpy(coursearray[i].code,"CS125");
	coursearray[i].reg_list = NULL;
	coursearray[i].waitlist = NULL;
	i++;
	coursearray[i].max_students = rand()%5 + 4;
	strcpy(coursearray[i].Name,"C Language");
	strcpy(coursearray[i].description,"Learning the fundaments of C Language");
	strcpy(coursearray[i].code,"CS127");
	coursearray[i].reg_list = NULL;
	coursearray[i].waitlist = NULL;
	i++;

}

/* insert when list is empty */
void first_insert(list **temp, student tempstud)
{
	list *newstudent = (list *)malloc(sizeof(list)*1);
	(newstudent->data).id = tempstud.id;
	strcpy((newstudent->data).Name.first,tempstud.Name.first);
	strcpy((newstudent->data).Name.last,tempstud.Name.last);
	newstudent->next = NULL;

	(*temp) = newstudent;
	return ;
}

/* insert when list is not empty */
void normal_insert(list **head, student tempstud)
{
	list *newstudent = (list *)malloc(sizeof(list)*1);
	(newstudent->data).id = tempstud.id;
	strcpy((newstudent->data).Name.first,tempstud.Name.first);
	strcpy((newstudent->data).Name.last,tempstud.Name.last);
	newstudent->next = NULL;

	list *temp = (*head);
	if(tempstud.id < (temp->data).id)
	{
		newstudent->next = (*head);
		(*head) = newstudent;
		return ;
	}

	while(temp->next != NULL)
	{
		if((temp->next->data).id <= tempstud.id){
			temp = temp->next;
			continue;
		}
		newstudent->next = temp->next;
		temp->next = newstudent;
		return ;	
	}
	temp->next = newstudent;
	return;
}

/* adding student to the course registration List */
void reg_student_into_course(course coursearray[], int cnumber, student studarray[], int snumber)
{
	student tempstud;
	tempstud.id = studarray[snumber].id;
	strcpy(tempstud.Name.last,studarray[snumber].Name.last);
	strcpy(tempstud.Name.first,studarray[snumber].Name.first);
	
	if(coursearray[cnumber].reg_list== NULL)
	{
		first_insert(&(coursearray[cnumber].reg_list), tempstud);
		return;
	}	
	normal_insert(&(coursearray[cnumber].reg_list), tempstud);
	return;
}


/* adding student to the course waitlist */
void add_student_to_waitlist(course coursearray[], int cnumber, student studarray[], int snumber)
{
	student tempstud;
	tempstud.id = studarray[snumber].id;
	strcpy(tempstud.Name.last,studarray[snumber].Name.last);
	strcpy(tempstud.Name.first,studarray[snumber].Name.first);
	

	if(coursearray[cnumber].waitlist == NULL)
	{
		first_insert(&(coursearray[cnumber].waitlist), tempstud);
		return;
	}	
	normal_insert(&(coursearray[cnumber].waitlist), tempstud);
	return;
}

/* printing registration list of course */
void print_reg_list(list *head, int cstrength, int max_students)
{
	printf("Registered Students (%d/%d)\n",cstrength,max_students);
	list *temp = head;
	while(temp!=NULL)
	{
		printf("*  %d - %s, %s\n",(temp->data).id,(temp->data).Name.last,(temp->data).Name.first);
		temp = temp->next;
	}
	return ;
}

/* printing waiting list of course */
void print_wait_list(list *head, int waitstrength)
{
	printf("Waiting List (%d)\n", waitstrength);
	list *temp = head;
	while(temp!=NULL)
	{
		printf("*  %d - %s, %s\n",(temp->data).id,(temp->data).Name.last,(temp->data).Name.first);
		temp = temp->next;
	}
	return ;
}

/* printing course information ... printing their registration list and waiting list info */
void print_course_info(course coursearray[],int cstrength[], int waitstrength[])
{
	int i;
	i=0;
	for(i=0;i<3;i++)
	{
		printf("%s - %s\n",coursearray[i].code,coursearray[i].Name);
		printf("%s\n",coursearray[i].description);
		print_reg_list(coursearray[i].reg_list,cstrength[i],coursearray[i].max_students);
		print_wait_list(coursearray[i].waitlist,waitstrength[i]);
	}
}
/* printing courses in which student is in waiting list */
void print_student_wait_list(course coursearray[], int studcourse[12][3], int studindex)
{
	int count;
	int k;
	k=0;
	count = 0;
	for(k=0;k<3;k++)
	{
		if(studcourse[studindex][k] == 2)
		{
			printf("* %s - %s\n",coursearray[k].code,coursearray[k].Name);
			count++;
		}
	}
	if(!count)
		printf("* None\n");
	return ;
}


/* sort the courese according to their code */
void sort(course coursearray[], int size)
{
	int i = 0,j;
	course temp;
	for(i=size-1;i>0;i--)
	{
		for(j=i-1;j>=0;j--)
		{
			if(strcmp(coursearray[i].code,coursearray[j].code)<0)
			{
				temp = coursearray[j];
				coursearray[j] = coursearray[i];
				coursearray[i] = temp;
			}
		}
	}
	return ; 
}

/* printing courses in which student has registered */
void print_student_reg_list(course coursearray[], int studcourse[12][3], int studindex)
{
	int count,k;
	count=0;
	k=0;
	for(k=0;k<3;k++)
	{
		if(studcourse[studindex][k] == 1)
		{
			printf("* %s - %s\n",coursearray[k].code,coursearray[k].Name);
			count++;
		}
	}
	if(count == 0)
		printf("* None\n");
	return ;
}


/* check whether the registration of the student is possible */
int check_registration_possible(int cstrength, int max_students, int present)
{
	if(present == 1)
		return 0;
	else if(cstrength < max_students)
		return 1;
	return 0;
}

/* check whether student get inserted into the waiting list */
int check_waiting_possible(int cstrength, int max_students, int present)
{
	if(present != 0)
		return 0;
	else if(cstrength == max_students)
		return 1;
	return 0;
}

/* function to test queries */
void test(course coursearray[], student studarray[], int studcourse[12][3])
{
	int tempid, flag =0,i;
	while(1)
	{
		flag = 0;
		printf("Enter a student id :-");
		scanf("%d",&tempid);
		if(tempid == 0)
		{
			printf("exiting\n");
			break;
		}
		for(i=0;i<12;i++)
		{
			if(studarray[i].id != tempid)continue;
			printf("%s, %s is registered for :-\n",studarray[i].Name.last, studarray[i].Name.first);
			flag = 1;
			print_student_reg_list(coursearray, studcourse, i);
			printf("On waiting list for :- \n");
			print_student_wait_list(coursearray, studcourse, i);
		}
		if(flag == 0)
			printf("No student found with the ID %d\n",tempid);

	}
}

/* function to free the course registration list and waiting list */
void memory_release(course coursearray[], int noofcourses)
{
	int i;
	for(i=0;i<noofcourses;i++)
	{
		if(coursearray[i].reg_list != NULL)
			free(coursearray[i].reg_list);
		if(coursearray[i].waitlist != NULL)
			free(coursearray[i].waitlist);
	}	
}
