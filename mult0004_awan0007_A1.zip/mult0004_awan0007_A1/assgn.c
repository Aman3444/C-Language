/* PROGRAM:  CST8234_010 
   AUTHOR:   Aman Multani , Maryum Awan 
   DATE:     30/11/17 
   TOPIC:    Assignment 1 
   PURPOSE:  To show the information about the student who are enrolled in the course or are on the waiting list. 
   CHALLENGES: randamization.
   LEVEL OF DEFFICULTY : 5
   TIME SPEND : 1 months
           
*/



#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>
#include "funct.h"

int main()
{
	srand(time(0));
	int j=0,i=0,cnumber;
	int waitstrength[3] = {0,0,0};
	
	/* initial declaration of courses and students */
	course coursearray[3];
	student studarray[12];	
	initialize_courses(coursearray);
	initialize_students(studarray);

	int studcourse[12][3];
	int cstrength[3] = {0,0,0};

	int noofcourses = 3;
	sort(coursearray,noofcourses);
	
	for(i=0;i<12;i++)
	{
		for(j=0;j<3;j++)
			studcourse[i][j] = 0;
	}

	for(j=0;j<2;j++)
	{
		for(i=0;i<12;i++)
		{
			cnumber = rand()%3;
			if(check_registration_possible(cstrength[cnumber],coursearray[cnumber].max_students,studcourse[i][cnumber]))
			{
				reg_student_into_course(coursearray, cnumber, studarray, i);
				studcourse[i][cnumber] = 1;	/*  registered into the course */
				cstrength[cnumber]++;
			}
			else if(check_waiting_possible(cstrength[cnumber],coursearray[cnumber].max_students,studcourse[i][cnumber]))
			{
				studcourse[i][cnumber] = 2;	/* inserted into waitlist */
				add_student_to_waitlist(coursearray, cnumber, studarray, i);
				waitstrength[cnumber]++;
			}
		}
	}
	print_course_info(coursearray,cstrength,waitstrength);	
	test(coursearray,studarray,studcourse);	/* function to test the queries */
	memory_release(coursearray, noofcourses);	/* function to free the memory */
	return 0;
}

