/* PROGRAM:  CST8234_010 
   AUTHOR:   Aman Multani , Maryum Awan 
   DATE:     30/11/17 
   TOPIC:    Assignment 1 
   PURPOSE:  To show the information about the student who are enrolled in the course or are on the waiting list. 
   CHALLENGES: randamization.
   LEVEL OF DEFFICULTY : 5
   TIME SPEND : 1 months
           
*/

#ifndef FUNCTIONS
#define FUNCTIONS

#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <stdio.h>

struct name
{
	char first[15];
	char last[15];
};
typedef struct name name;

struct stud
{
	int id;
	name Name;
};
typedef struct stud student;

struct list
{
	student data;
	struct list *next;
};
typedef struct list list;

struct course
{
	char Name[20];
	char description[50];
	char code[6];
	int max_students;
	list *reg_list;
	list *waitlist;
};
typedef struct course course;

void initialize_students(student studarray[]);
void initialize_courses(course coursearray[]);
void first_insert(list **temp, student tempstud);
void normal_insert(list **head, student tempstud);
void reg_student_into_course(course coursearray[], int cnumber, student studarray[], int snumber);
void add_student_to_waitlist(course coursearray[], int cnumber, student studarray[], int snumber);
void print_reg_list(list *head, int cstrength, int max_students);
void print_wait_list(list *head, int waitstrength);
void print_course_info(course coursearray[],int cstrength[], int waitstrength[]);
void sort(course coursearray[], int size);
void print_student_reg_list(course coursearray[], int studcourse[12][3], int studindex);
void print_student_wait_list(course coursearray[], int studcourse[12][3], int studindex);
int check_registration_possible(int cstrength, int max_students, int present);
int check_waiting_possible(int cstrength, int max_students, int present);
void test(course coursearray[], student studarray[], int studcourse[12][3]);
void memory_release(course coursearray[], int noofcourses);

#endif
