#include "declare.h"

void input(){

     printf("Please enter number of players: ");
     scanf("%d", &player);

/*check if the a Character is enter or the number less than 2 or more than 4*/
if (2>player || player>4){
     printf("please enter 2,3 or 4 for the no.player & No character are accepted . \n");
     exit(0);    
}

     printf("enter number of cards to be distrubuted to each player: ");
     scanf("%d", &n_cards);


/*checks if the number of cards are less than 2 or more than 26*/
if(2>n_cards|| n_cards>26){
     printf("enter a number between 2-26 & No character are accepted\n");
	printf("&&  Number of cards can not be more than number of players!\n");     
exit(0);
}
/*checks the no. of cards and no. player are more than 52 or not */
    else if ((n_cards*player)>52){
	
	printf("Number of cards can not be more than number of players!\n");
	exit(0);

}


}
