/**************************************************************************/
/* Declare include files
 **************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#define  TRUE 1
#define  FALSE 0
#define  BOOL int
#define N_suits 4
#define N_ranks 13


/* to hold the value for PLayers And Cards*/
int player;
int n_cards;



int n_cards_disti;
int rank;
int suit;
int i;

/*Gets the input of the players and the no. of cards to distribute*/
void input();
/*Scan the inputs and looks those given condition base on the user input*/
void playIt();
