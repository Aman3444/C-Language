void generate(int player, int n_cards_disti, int num_cards, int suits, int rank,int i){


for( i=1; i<=player; i++){
		
	    num_cards_distributed = num_cards;

            printf("hand #%d: \n",i);
          

            while(num_cards_distributed > 0) {

            suit = rand() % N_suits;
            rank = rand() % N_ranks;

 }

  }

   }

