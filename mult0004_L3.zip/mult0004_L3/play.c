#include "declare.h"



void run(){


/*the first array is for the ranks and the second array is for suits of all the cards*/
            const char rank_code[] = {'2','3','4','5','6','7','8',
                                      '9','T','J','Q','K','A'};
            const char suit_code[] = {'C','D','H','S'};

    /*checks if there are duplicates or not in the cards*/       
BOOL in_hand[N_suits][N_ranks] = {FALSE};
	 srand( time(NULL));

/*display no. of hands according to the no. of players*/
           for( i=1; i<=player; i++){
		
	    n_cards_disti = n_cards;

            printf("hand #%d:\n",i);
          

            while(n_cards_disti > 0) {

            suit = rand() % N_suits;/*generating random suits */
            rank = rand() % N_ranks;/*ge nerating random ranks*/
            
          
 
            if (!in_hand[suit][rank]) {
               in_hand[suit][rank] = TRUE;
               n_cards_disti--;
               printf(" %c%c\n", rank_code[rank], suit_code[suit]);/*display the random suits and ranks for the cards */

              }
            }


}

     
	
}
