/* PROGRAM:  lab3
   AUTHOR:  Multani Aman Altaf 
   DATE:  09 - 26 -2017 
   PURPOSE: shuffle the cards
   LEVEL OF DIFFICULTY: 5
   CHALLENGES: a lot
   HOURS SPENT: 4 days          
*/



#include "declare.h"

int main()
	{
		input();/*calls the input.c files*/
		run();/*calls the run() constructor fron play.c file*/
		return 0;
	}
